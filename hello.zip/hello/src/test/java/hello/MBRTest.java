package hello;

import com.rk.bo.MBRBO;
import com.rk.dao.MBRDAO;

public class MBRTest {
	
	public static void main(String args[])
	{
		MBRBO  mr = new MBRBO();
		mr.setName("RK1");
		mr.setSummary("RKSummary1");
		mr.setDetail("RKDetails1");
		
		MBRDAO dao = new MBRDAO();
		dao.insert(mr);
		
	
	}

}
