package com.rk.dao;

import com.rk.bo.MBRBO;
import static com.rk.util.MySQLDBUtil.*;
public class MBRDAO {
	
	public int insert(MBRBO mr)
	{
		int count =0;
		connectDB();
		String updateQ = "INSERT INTO mbr_info(name, summary, detail) "
				+ "VALUES ('"+mr.getName()+"', '"+mr.getSummary()+"', '"+mr.getDetail()+"');";
		count = updateQuery(updateQ);
		closeConnection();
		return count;
	}

}
