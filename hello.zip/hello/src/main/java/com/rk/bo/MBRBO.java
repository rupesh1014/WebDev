package com.rk.bo;

public class MBRBO {
	
	int id;
	String name;
	String summary;
	String detail;
	
	public int getId()
	{
		return this.id;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public String getSummary()
	{
		return this.summary;
	}
	
	public String getDetail()
	{
		return this.detail;
	}
	
	public void setId(int id)
	{
		this.id = id;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setSummary(String summary)
	{
		this.summary = summary;
	}
	
	public void setDetail(String detail)
	{
		this.detail = detail;
	}
	

}
