package com.rk.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class MySQLDBUtil {
	
	static String dbURL = "jdbc:mysql://127.0.0.1:3306/mydb";
	static String userID = "root";
	static String password = "root";
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement ps = null;
	static Statement st = null;

	
	public static void connectDB()
	{
		try {
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(dbURL,userID,password);
		if(conn!=null)
			System.out.println("DB connection established.");
		
		
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	}

	public static ResultSet runQuery(String query)
	{
		try {
		st = conn.createStatement();
		rs = st.executeQuery(query);
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return rs;
	}
	
	public static int updateQuery(String query)
	{
		int count = 0;
		try {
		ps = conn.prepareStatement(query);
		count = ps.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		System.out.println("Rows udpated "+count);
		return count;
	}
	
	public static void closeConnection()
	{
		if(conn!=null)
			try {
				conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
	
	public static void main(String args[])
	{
			connectDB();
			ResultSet rs = runQuery("SELECT * FROM mydb.mbr_info;");
			try {
				while(rs.next())
				{
					System.out.println("ID "+rs.getString("id"));
					System.out.println("Name "+rs.getString("name"));
					System.out.println("Summary "+rs.getString("summary"));
					System.out.println("Detail  "+rs.getString("detail"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String updateQ = "INSERT INTO mbr_info(name, summary, detail) VALUES ('rk', 'd', 'd');";
			updateQuery(updateQ);
			closeConnection();
	}
	
}
